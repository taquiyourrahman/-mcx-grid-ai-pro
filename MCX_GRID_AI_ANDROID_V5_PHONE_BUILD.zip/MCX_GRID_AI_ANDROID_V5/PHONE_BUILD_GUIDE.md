# Build the APK using only your Android phone

This uses GitHub's cloud runner. You do not need a computer. You need a GitHub account and internet access.

## A. Upload this project to GitHub
1. Open Chrome on your phone and go to https://github.com
2. Sign in or create a free account.
3. Tap **New repository**. Name it `mcx-grid-ai-paper`. Choose **Public** (recommended for free Actions minutes) and create it.
4. Open the new empty repository, tap **Add file** > **Upload files**.
5. Extract this ZIP on your phone first (Files app > Downloads > ZIP > Extract).
6. In GitHub's upload page, upload the contents of the extracted `MCX_GRID_AI_ANDROID_V5` folder, including the hidden `.github` folder. If the mobile page hides dot-folders or cannot upload folders, use GitHub's browser desktop-site mode or upload the files individually and create `.github/workflows/android.yml` using Add file > Create new file.
7. Commit the files to the `main` branch.

## B. Start the cloud build
1. In the repository, open the **Actions** tab.
2. If GitHub asks to enable Actions, enable them.
3. Select **Build Android APK** from the workflow list.
4. Tap **Run workflow** > **Run workflow**.
5. Wait for the run to finish with a green check mark.

## C. Download and install
1. Open the completed workflow run.
2. Scroll to **Artifacts**.
3. Tap `MCX-GRID-AI-PAPER-APK` to download the ZIP artifact.
4. Extract it on your phone. It contains `app-debug.apk`.
5. Tap the APK and allow installation from that source if Android asks. Only install the APK you built in your own repository.

## If the mobile upload page is difficult
Use Chrome's three-dot menu > **Desktop site**. GitHub's mobile UI changes periodically, so labels may vary.

## Safety and limits
The app is a paper-trading demonstration only. It has no live MCX data feed, Angel One connection, or order placement. It does not model actual contract lots, margin, brokerage, taxes, or slippage. Do not use its demo signals for real trades.
