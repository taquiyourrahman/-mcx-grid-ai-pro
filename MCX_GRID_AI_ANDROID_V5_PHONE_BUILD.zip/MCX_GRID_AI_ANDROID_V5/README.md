# MCX GRID AI PRO V5 — Android paper simulator

This is a starter Android Studio project. It is **paper-only**:
- no Angel One login or API credentials
- no market-data feed
- no broker order placement
- no live trading

## Build an APK
1. On a computer, install Android Studio (current stable) and Android SDK Platform 35.
2. Extract this ZIP and open the `MCX_GRID_AI_ANDROID_V5` folder in Android Studio.
3. Allow Gradle sync to finish. Use JDK 17.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location (normally `app/build/outputs/apk/debug/app-debug.apk`).
6. Transfer that APK to your Android phone and install it. Only install APKs you built or trust.

## Use
Enter virtual capital, a manually observed price, and a previous reference price. Tap **Run paper signal**. This is a simple momentum demonstration, not a trained AI model and not a validated profitable strategy.

## Risk / limitations
The entered “units” are simulation units, not verified MCX contract lots. The app does not calculate exchange margin, brokerage, taxes, slippage, tick sizes, or expiry rules. It must not be used to decide or execute real trades. A ₹5,000 virtual balance does not imply that any MCX futures contract is affordable.
