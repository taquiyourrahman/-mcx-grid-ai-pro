package com.example.mcxgridpaper

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import java.util.Locale
import kotlin.math.abs

data class PaperTrade(val side: String, val entry: Double, val qty: Int, val note: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { PaperDashboard() } }
    }
}

@Composable
fun PaperDashboard() {
    var priceText by remember { mutableStateOf("7000") }
    var previousText by remember { mutableStateOf("6990") }
    var capitalText by remember { mutableStateOf("5000") }
    var lotText by remember { mutableStateOf("1") }
    var status by remember { mutableStateOf("Ready — enter a sample MCX price to test.") }
    var trade by remember { mutableStateOf<PaperTrade?>(null) }
    var closedPnl by remember { mutableDoubleStateOf(0.0) }
    var peak by remember { mutableDoubleStateOf(0.0) }
    var showHelp by remember { mutableStateOf(false) }

    val price = priceText.toDoubleOrNull() ?: 0.0
    val previous = previousText.toDoubleOrNull() ?: 0.0
    val capital = capitalText.toDoubleOrNull() ?: 0.0
    val qty = lotText.toIntOrNull()?.coerceAtLeast(1) ?: 1
    val unrealized = trade?.let { (price - it.entry) * it.qty * if (it.side == "LONG") 1 else -1 } ?: 0.0
    val equity = capital + closedPnl + unrealized

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("MCX GRID AI PRO", style = MaterialTheme.typography.headlineMedium)
        Text("V5 • Android paper-trading simulator", style = MaterialTheme.typography.bodyMedium)
        Card {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("PAPER MODE ONLY", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)
                Text("No broker login • No live orders • No real-money execution")
            }
        }
        Text("Account overview", style = MaterialTheme.typography.titleLarge)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Metric("Virtual capital", "₹${fmt(capital)}", Modifier.weight(1f))
            Metric("Paper equity", "₹${fmt(equity)}", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Metric("Closed P&L", "₹${fmt(closedPnl)}", Modifier.weight(1f))
            Metric("Open P&L", "₹${fmt(unrealized)}", Modifier.weight(1f))
        }

        Text("Simulator inputs", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(value = capitalText, onValueChange = { capitalText = it }, label = { Text("Virtual capital (₹)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = priceText, onValueChange = { priceText = it }, label = { Text("Current MCX price (manual)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = previousText, onValueChange = { previousText = it }, label = { Text("Previous reference price") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = lotText, onValueChange = { lotText = it }, label = { Text("Units for simulation (not actual lot sizing)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())

        Button(onClick = {
            if (price <= 0.0 || previous <= 0.0 || capital <= 0.0) {
                status = "Enter valid positive numbers."
            } else if (trade != null) {
                status = "Close the open paper position before opening another."
            } else {
                val changePct = (price - previous) / previous * 100.0
                val riskBudget = capital * 0.01
                val stopDistance = price * 0.005
                val allowedQty = (riskBudget / (stopDistance * qty)).toInt()
                if (allowedQty < 1) {
                    status = "Risk filter: position skipped. One simulated unit exceeds the 1% risk budget."
                } else if (abs(changePct) < 0.05) {
                    status = "No trade: price movement is below the 0.05% signal threshold."
                } else {
                    val side = if (changePct > 0) "LONG" else "SHORT"
                    trade = PaperTrade(side, price, qty, "Rule-based momentum test")
                    status = "$side paper position opened at ₹${fmt(price)}. This is a demo signal, not a recommendation."
                }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Run paper signal") }

        if (trade != null) {
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Open paper position", style = MaterialTheme.typography.titleMedium)
                    Text("${trade!!.side} • Entry ₹${fmt(trade!!.entry)} • Units ${trade!!.qty}")
                    Text("Unrealized P&L: ₹${fmt(unrealized)}")
                    Button(onClick = {
                        closedPnl += unrealized
                        if (closedPnl > peak) peak = closedPnl
                        status = "Paper position closed. P&L added to simulator."
                        trade = null
                    }, modifier = Modifier.fillMaxWidth()) { Text("Close paper position") }
                }
            }
        }
        Card {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Strategy status", style = MaterialTheme.typography.titleMedium)
                Text(status)
                Text("Risk guardrails: 1% virtual risk budget per entry • one open position • no leverage.")
            }
        }
        OutlinedButton(onClick = { showHelp = !showHelp }, modifier = Modifier.fillMaxWidth()) {
            Text(if (showHelp) "Hide instructions" else "How to use")
        }
        if (showHelp) {
            Text("1. Enter a virtual capital amount. 2. Type a current price and a previous reference price manually. 3. Tap Run paper signal. 4. Review open P&L and close the simulated trade. Values are for software testing only. The app does not fetch live MCX prices and does not know contract lot sizes, margins, taxes or brokerage.")
        }
        Text("Important: ₹5,000 is only virtual test capital. Many MCX futures contracts require substantially more margin. Verify exchange contract specifications and all costs before any independent trading decision.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun Metric(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(12.dp)) {
        Text(label, style = MaterialTheme.typography.bodySmall)
        Text(value, style = MaterialTheme.typography.titleMedium)
    } }
}

fun fmt(value: Double): String = String.format(Locale.US, "%,.2f", value)
